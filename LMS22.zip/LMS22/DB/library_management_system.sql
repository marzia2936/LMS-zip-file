-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2020 at 07:40 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `library_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_circulation_info`
--

CREATE TABLE IF NOT EXISTS `book_circulation_info` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn_number` varchar(32) NOT NULL,
  `book_title` varchar(32) NOT NULL,
  `book_author` varchar(32) NOT NULL,
  `book_edition` varchar(32) NOT NULL,
  `publication_year` varchar(32) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `book_circulation_info`
--

INSERT INTO `book_circulation_info` (`book_id`, `isbn_number`, `book_title`, `book_author`, `book_edition`, `publication_year`) VALUES
(1, '552000', '2554', 'Marzia', '2019', '02145');

-- --------------------------------------------------------

--
-- Table structure for table `book_collection_info`
--

CREATE TABLE IF NOT EXISTS `book_collection_info` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `total_number_of_books` varchar(32) NOT NULL,
  `total_issued_books` varchar(32) NOT NULL,
  `total_available_books` varchar(32) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `book_collection_info`
--

INSERT INTO `book_collection_info` (`book_id`, `total_number_of_books`, `total_issued_books`, `total_available_books`) VALUES
(1, 'Marzia khatun', '120', '200'),
(2, 'dffdf', '2000', 'fdfdfdg'),
(3, 'mmmmm', 'fffff', 'fffff');

-- --------------------------------------------------------

--
-- Table structure for table `book_info`
--

CREATE TABLE IF NOT EXISTS `book_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` varchar(32) NOT NULL,
  `book_name` varchar(32) NOT NULL,
  `book_author` varchar(32) NOT NULL,
  `book_edition` varchar(32) NOT NULL,
  `publication_year` varchar(32) NOT NULL,
  `isbn_number` varchar(32) NOT NULL,
  `book_price` varchar(32) NOT NULL,
  `book_category` varchar(32) NOT NULL,
  `book_location` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `book_info`
--

INSERT INTO `book_info` (`id`, `book_id`, `book_name`, `book_author`, `book_edition`, `publication_year`, `isbn_number`, `book_price`, `book_category`, `book_location`) VALUES
(1, '1', 'Easy Computer & ICT', 'Dr. Md. Shahnewaz Hossain', '2012', '2020', '978-984-33-9446-0', '260', '3', 'Shelf-1');

-- --------------------------------------------------------

--
-- Table structure for table `book_shelf_info`
--

CREATE TABLE IF NOT EXISTS `book_shelf_info` (
  `book_shelf_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_shelf_name` varchar(32) NOT NULL,
  `book_shelf_location` varchar(32) NOT NULL,
  PRIMARY KEY (`book_shelf_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `book_shelf_info`
--

INSERT INTO `book_shelf_info` (`book_shelf_id`, `book_shelf_name`, `book_shelf_location`) VALUES
(1, 'Marzia321', 'shelfaaaaa'),
(2, 'Marzia', 'Marzia');

-- --------------------------------------------------------

--
-- Table structure for table `category_info`
--

CREATE TABLE IF NOT EXISTS `category_info` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(32) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `category_info`
--

INSERT INTO `category_info` (`category_id`, `category_name`) VALUES
(1, 'C Programming'),
(2, 'Computer Fundamentals'),
(3, 'Computer Science');

-- --------------------------------------------------------

--
-- Table structure for table `issue_new_book`
--

CREATE TABLE IF NOT EXISTS `issue_new_book` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_library_id` varchar(32) NOT NULL,
  `student_name` varchar(32) NOT NULL,
  `book_name` varchar(32) NOT NULL,
  `isbn_number` varchar(32) NOT NULL,
  `issue_date` date NOT NULL,
  `return_date` varchar(32) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `issue_new_book`
--

INSERT INTO `issue_new_book` (`student_id`, `student_library_id`, `student_name`, `book_name`, `isbn_number`, `issue_date`, `return_date`) VALUES
(2, '1122000', 'Marzia', 'Database ', '1100222', '2020-11-11', ''),
(3, '0123', 'Mst Marzia Khatun', 'Java Progrmming', '1112223', '2020-11-12', 'Not Return Yet');

-- --------------------------------------------------------

--
-- Table structure for table `role_info`
--

CREATE TABLE IF NOT EXISTS `role_info` (
  `role_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_info_name` varchar(32) NOT NULL,
  `role_info_email` varchar(32) NOT NULL,
  `role_description` varchar(64) NOT NULL,
  PRIMARY KEY (`role_info_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `role_info`
--

INSERT INTO `role_info` (`role_info_id`, `role_info_name`, `role_info_email`, `role_description`) VALUES
(1, 'marzia', 'marziakhatun1999@gmail.com', 'student'),
(2, 'fgfg', '', 'agf'),
(3, 'fg', '', 'sss'),
(4, 'Marzia', 'marzia35-2936@diu.edu.bd', 'She is a student'),
(5, 'Marzia', 'marziakhatun1999@gmail.com', 'student'),
(6, 'marzia', 'aaa', 'aaaa'),
(7, 'aaaa', 'aaa', 'aaaa');

-- --------------------------------------------------------

--
-- Table structure for table `staff_info`
--

CREATE TABLE IF NOT EXISTS `staff_info` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(32) NOT NULL,
  `staff_designation` varchar(32) NOT NULL,
  `staff_email` varchar(32) NOT NULL,
  `staff_contact_no` varchar(11) NOT NULL,
  `staff_address` varchar(64) NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `staff_info`
--

INSERT INTO `staff_info` (`staff_id`, `staff_name`, `staff_designation`, `staff_email`, `staff_contact_no`, `staff_address`) VALUES
(1, 'Marzia', 'ms', 'marziakhatun1999@gmail.com', '01724294285', 'Agargaon'),
(2, 'hlkjlkj', 'hl', 'deuroie', 'ujkj', 'dfdfj;l');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE IF NOT EXISTS `student_info` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_library_id` varchar(32) NOT NULL,
  `student_name` varchar(32) NOT NULL,
  `student_email` varchar(32) NOT NULL,
  `student_contact_no` varchar(32) NOT NULL,
  `student_address` varchar(32) NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_id`, `student_library_id`, `student_name`, `student_email`, `student_contact_no`, `student_address`) VALUES
(1, '01112225550', 'Marzia Khatun', 'marziakhatun1999@gmail.com', '01724490193', 'West Agargaon'),
(2, '01122444', 'Marzia', 'marziakhatun1999@gmail.com', '01724294285', '246/1/F/A,West Agargaon');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_info`
--

CREATE TABLE IF NOT EXISTS `supplier_info` (
  `sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_name` varchar(64) NOT NULL,
  `sup_email` varchar(32) NOT NULL,
  `sup_contact_no` varchar(32) NOT NULL,
  PRIMARY KEY (`sup_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `supplier_info`
--

INSERT INTO `supplier_info` (`sup_id`, `sup_name`, `sup_email`, `sup_contact_no`) VALUES
(1, ' Marzia ', 'marziakhatun1999.com', '01724294285'),
(2, 'marzia', 'marziakhatun19', '01724294285'),
(4, '444', 'ddd', 'dddd');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `contact` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `username`, `password`, `contact`, `status`) VALUES
(1, 'admin', '123', '01724294285', 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `writer_info`
--

CREATE TABLE IF NOT EXISTS `writer_info` (
  `writer_id` int(11) NOT NULL AUTO_INCREMENT,
  `writer_name` varchar(64) NOT NULL,
  `writer_type` varchar(32) NOT NULL,
  `writer_email` varchar(32) NOT NULL,
  `writer_contact_no` varchar(32) NOT NULL,
  PRIMARY KEY (`writer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `writer_info`
--

INSERT INTO `writer_info` (`writer_id`, `writer_name`, `writer_type`, `writer_email`, `writer_contact_no`) VALUES
(1, 'Marzia Khatun', 'student', 'marziakhatun1999@gmail.com', '016244901936'),
(2, 'fsfg', 'fg', 'dfg', 'sg'),
(3, 'jjjjj', 'ssss', 'kkkkk', 'bbbb');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
