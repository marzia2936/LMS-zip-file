<?php


	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "library_management_system";
	
	//Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);





?>