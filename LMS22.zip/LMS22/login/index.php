<?php include("header.php");
include('connection.php');
 ?>
<?php

	//check if user is not logged in
	if(empty($_SESSION["user_id"])){
	header("Location:login.php");
		exit();
	}
	
	//get session id
	//$user_id = $_SESSION["user_id"];
	
	//$sql = "SELECT * FROM users WHERE id = $user_id";
	//$query = $conn->query($sql);
	//$result = $query->fetch_array();
	
	//close database connection
	//$conn->close();
?>


<div class="content_right"><!--Content_right Start-->
	<div class="form">
		
		
		
		<h2 style="text-align:center;">Welcome to our Library Management System</h2>
		<br/>
		<h2 style="text-align:center;">Date : <?php echo date('d-M-Y'); ?></h2>
		<img src="img/Library-1.jpg" width="100%" height="490px"/>

		
	</div>
</div><!--Content_Right End-->




